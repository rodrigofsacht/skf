# skf
Safe Key Find in dict


Sample

mydict = {
    'address': {
        'city': 'Ney York'
    }
}

skf(mydict, ['address', 'city'])
